
package unittesting;

/**
 *
 * @author Summer
 */
public class UnitTesting {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
    }
  
    public String concatenate(String one, String two){
        return one + two;
    }
    
}
